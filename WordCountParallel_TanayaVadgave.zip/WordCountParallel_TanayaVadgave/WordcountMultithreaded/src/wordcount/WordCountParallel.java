package wordcount;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;
import java.util.logging.Logger;

import org.junit.Test;


/*
 * @author: Tanaya Vadgave
 */
public class WordCountParallel
{
	    private static final int THREAD_COUNT = 4;
	    private final static String DELIMITERS = " :;,.{}()?!\"\t\n";
	    private static final Logger LOGGER = Logger.getLogger(WordCountParallel.class.getName());
	
	    public static void main(String[] args) throws Exception{
	    	
	    	StringOperations strOp = new StringOperations();
	        Map<String, Integer> wordCountMaps = new HashMap<String, Integer>();
	        
	        StringOperations strOpSeq = new StringOperations();
	        Map<String, Integer> wordCountMapsSeq = new HashMap<String, Integer>();
	        
	        final Queue<String> stringQueue = new ConcurrentLinkedQueue<String>();
	        
	        int chunksize = 1000;
	        boolean flag = false;
	        
	        if(args.length == 0){
	        	args = new String[4];
	        	args[0] = "/file1.txt";
	        	args[1] = "/file2.txt";
	        	args[2] = "/file3.txt";
	        	args[3] = "/file4.txt";
	        	flag = true;
	        	
	        }
	        
	        //parse command line arguments
	        for(int j=0; j<args.length; j++){	        	
	        	
	        	LOGGER.info("File Path: " + args[j]);
	        	
	        	BufferedReader reader;
	        	
	        	if(flag == true){
		        	InputStream ip = WordCountParallel.class.getResourceAsStream(args[j]);
		        	InputStreamReader inputReader = new InputStreamReader(ip);	        	
		        	reader = new BufferedReader(inputReader);
	        	}else{
	        		reader = new BufferedReader(new FileReader(args[j]));
	        	}
	        	
	        	String brokenString = "";
	        			
	        	while(true){
	        				 
	        		String res = convertFileToString(reader,chunksize);
	        		if (res.equals("")) {
	        		    	if (!brokenString.equals("")) 
	        		    		stringQueue.add(brokenString);
	        		            break;
	        		}
	        		            
	        	   	int idx = checkDelimIndex(res);
	        	   	String taskstr = brokenString + res.substring(0,idx);
	        	    stringQueue.add(taskstr);
	        	    brokenString = res.substring(idx,res.length());    
	        	}
	            
	        	//Sequencial way:
	        	Queue<String> stringQueueSeq = new ConcurrentLinkedQueue<String>(stringQueue);
	        	SequencialWordCount sq = new SequencialWordCount(strOpSeq,wordCountMapsSeq,stringQueueSeq);
	        	wordCountMapsSeq =  sq.sequencialWordCount();
	        	LOGGER.info("Word Count sequencial: " + wordCountMapsSeq);
	        	
	        	//Multithreading way:
	            ExecutorService es = Executors.newFixedThreadPool(THREAD_COUNT);
	            for (int i=0; i<THREAD_COUNT; i++) {
	            	es.execute(new Multithreading(strOp, wordCountMaps, stringQueue));
	            }
	            es.shutdown();
	            es.awaitTermination(1, TimeUnit.MINUTES);	
	            LOGGER.info("Word Count parallel: " + wordCountMaps);
	            LOGGER.info("");
	            
	            if(wordCountMapsSeq.equals(wordCountMaps)){
	            	
	            	LOGGER.info("Test case for "+ j +" passed!!!"+"\n");
	            }
	            else{
	            	
	            	LOGGER.info("Test case for "+ j + " not passed!!!"+"\n");
	            }
	        }
	        
	        //Unit Tests check:
	        UnitTests ut = new UnitTests();
	        
	        ut.checkDelimIndexTest("Christmas is one of the most popular festivals worldwide.", 56);
	        
	        String[] str = {"Into", "the", "ocean", "123abc!"};
	        String[] output = {"Into", "the", "ocean"};
	        ut.validWordTokensTest(str, output);
	        
	        String[] str1 = {"INTO", "The", "OcEan"};
	        String[] output1 = {"into", "the", "ocean"};
	        ut.convertToLowercaseTest(str1, output1);
	        
	        String str2 = "Into the Ocean";
	        String[] output2 = {"Into", "the", "Ocean"};
	        ut.tokenizeTest(str2, output2);
	        
	    }
	      
    
	    private static String convertFileToString(BufferedReader reader, int size) throws IOException {
	    	
	            StringBuffer fileContent = new StringBuffer(size);
	            int index=0;
	
	            while(size > 0) {
	                int bufferSize = 1024 > size ? size : 1024;
	                char[] charBuffer = new char[bufferSize];
	              
					index = reader.read(charBuffer,0,bufferSize);
					
	                if (index == -1)
	                    break;
	                String data = String.valueOf(charBuffer, 0, index);
	                fileContent.append(data);
	                size -= index;
	            }
	            return fileContent.toString();
	    }
    
	    private static int checkDelimIndex(String str) {
	        for (int i=str.length()-1; i>=0; i--) {
	            for (int j=0; j<DELIMITERS.length(); j++) {
	                char d = DELIMITERS.charAt(j);
	                if (d == str.charAt(i)) 
	                	return i;
	            }
	        }
	        return 0;
	    }
    
	  private static class StringOperations{
	    	
	        private String[] validWordTokens(String[] words){
	            List<String> list = new ArrayList<String>();
	            for (String word : words) {
	                if (word.matches("[a-zA-Z0-9]+")) {
	                	list.add(word);
	                }
	            }
	            return list.toArray(new String[list.size()]);
	        }
	
	        public synchronized void updateCount(Map<String, Integer> wordCountMap, String word){
	            if (wordCountMap.containsKey(word)) {
	                wordCountMap.put(word,wordCountMap.get(word)+1);
	            } else {
	                wordCountMap.put(word,1);
	            }
	        }
	        
	        private String[] convertToLowercase(String[] words){
	            String[] list = new String[words.length];
	            for (int i = 0; i < words.length; i++) {
	            	list[i] = words[i].toLowerCase();
	            }
	            return list;
	        }
	   
	        //Split by white space/+
	        public String[] tokenize( String str ){
	            return str.split("\\W+");
	        }
	        
	    
	    }
	  
	  private static class SequencialWordCount{
		  
		  private Queue<String> stringQueueSeq;
	      private Map<String, Integer> wordCountMapsSeq;
	      private StringOperations strOpSeq;	
	
	      public SequencialWordCount(StringOperations strOpSeq, Map<String, Integer> wordCountMapsSeq, Queue<String> stringQueueSeq){
	          this.strOpSeq = strOpSeq;
	          this.stringQueueSeq = stringQueueSeq;
	          this.wordCountMapsSeq = wordCountMapsSeq;
	      }
	      
	      public Map<String, Integer> sequencialWordCount(){
		    	while (!stringQueueSeq.isEmpty()) {
		              String line = stringQueueSeq.poll();
		              if (line != null) {
		                  String[] words = strOpSeq.tokenize(line);
		                  String[] validWords = strOpSeq.validWordTokens(words);
		                  String[] lowercaseWords = strOpSeq.convertToLowercase(validWords);
		                  for (String word:lowercaseWords) {
		                	  strOpSeq.updateCount(wordCountMapsSeq, word);
		                  }
		              }
		        }
		    	
		    	return wordCountMapsSeq;
		    	
		    }
	      
	  }
  
	  private static class Multithreading implements Runnable{
		  
		  private Queue<String> stringQueue;
	      private Map<String, Integer> wordCountMaps;
	      private StringOperations strOp;	
	
	      public Multithreading(StringOperations strOp, Map<String, Integer> wordCountMaps, Queue<String> stringQueue){
	          this.strOp = strOp;
	          this.stringQueue = stringQueue;
	          this.wordCountMaps = wordCountMaps;
	      }
	
	      public void run(){
	          while (!stringQueue.isEmpty()) {
	              String line = stringQueue.poll();
	              if (line != null) {
	                  String[] words = strOp.tokenize(line);
	                  String[] validWords = strOp.validWordTokens(words);
	                  String[] lowercaseWords = strOp.convertToLowercase(validWords);
	                  for (String word:lowercaseWords) {
	                  	strOp.updateCount(wordCountMaps, word);
	                  }
	              }
	          }
	      }
	      
	  }
	  
	  
	  public static class UnitTests {
		  
		  	// test case to find delimitor index
		    @Test
		    public void checkDelimIndexTest(String str, int expectedIndex){
		        assertEquals(expectedIndex, checkDelimIndex(str));
		    }
		    
		    // test to see if all illegal words get removed
		    @Test
		    public void validWordTokensTest(String[] str, String[] output1){

		        StringOperations strOps = new StringOperations();
		        assertArrayEquals(output1, strOps.validWordTokens(str));
		    }
		    
		    // test to covert words to lowercase from array
		    @Test
		    public void convertToLowercaseTest(String[] str, String[] output1){
		         
		        StringOperations strOps = new StringOperations();
		        assertArrayEquals(output1, strOps.convertToLowercase(str));
		    }
		    
		    // Test method to tokenize a string
		    @Test
		    public void tokenizeTest(String str, String[] output1){
		         
		        StringOperations strOps = new StringOperations();
		        assertArrayEquals(output1, strOps.tokenize(str));
		    }
		       
	}
	   
}


